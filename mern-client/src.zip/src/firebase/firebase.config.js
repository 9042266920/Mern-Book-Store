// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDue7k-L1AjGv3u66boWfg_5WZ48B5KiEc",
  authDomain: "mern-book-store-b5b86.firebaseapp.com",
  projectId: "mern-book-store-b5b86",
  storageBucket: "mern-book-store-b5b86.appspot.com",
  messagingSenderId: "1057370987879",
  appId: "1:1057370987879:web:a6781320f6eadcf114e3c2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;