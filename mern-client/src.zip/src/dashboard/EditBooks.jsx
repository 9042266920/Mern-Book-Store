import React, { useState } from 'react';
import { useLoaderData, useParams } from 'react-router-dom';
import { Label, TextInput, Textarea, Button } from 'flowbite-react'; // Ensure you import your components properly

const EditBook = () => {
    const { id } = useParams();
    const { bookTitle, authorName, imageurl, bookDescription, bookPdfUrl } = useLoaderData();
    
    const bookCategories = [
        'Science Fiction',
        'Thriller',
        'Non-Fiction',
        'Children',
        'Horror',
        'History',
        'Fantasy',
        'Autobiography',
        'Business',
        'Travel',
        'Religion',
        'Art and Design',
    ];
    
    const [selectedBookCategory, setSelectedBookCategory] = useState(bookCategories[0]);
    
    const handleChangeSelectedValue = (event) => {
        setSelectedBookCategory(event.target.value);
    };
    
    const handleUpdate = (event) => {
        event.preventDefault();
        const form = event.target;

        const bookObj = {
            bookTitle: form.bookTitle.value,
            authorName: form.authorName.value,
            imageurl: form.imageurl.value,
            category: form.categoryName.value,
            bookDescription: form.bookDescription.value,
            bookPdfUrl: form.bookPdfUrl.value,
        };

        // Ensure to use template literals correctly
        fetch(`http://localhost:5000/books/${id}`, {
            method: "PATCH",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(bookObj),
        })
        .then(res => {
            if (!res.ok) {
                throw new Error("Failed to update the book");
            }
            return res.json();
        })
        .then(data => {
            alert("Book is updated successfully!!!");
            form.reset();
        })
        .catch(error => console.error("Error updating book:", error));
    };
    
    return (
        <div className="px-4 my-12">
            <h2 className="mb-8 text-3xl font-bold">Update A Book</h2>
            <form onSubmit={handleUpdate} className="flex lg:w-[1180px] flex-col flex-wrap gap-4">
                <div className="flex gap-8">
                    <div className="lg:w-1/2">
                        <div className="mb-2 block">
                            <Label htmlFor="bookTitle" value="Book Title" />
                        </div>
                        <TextInput
                            id="bookTitle"
                            type="text"
                            name="bookTitle"
                            placeholder="Book name"
                            defaultValue={bookTitle} // Set default value
                            required
                        />
                    </div>
                    <div className="lg:w-1/2">
                        <div className="mb-2 block">
                            <Label htmlFor="authorName" value="Author Name" />
                        </div>
                        <TextInput
                            id="authorName"
                            type="text"
                            name="authorName"
                            placeholder="Author Name"
                            defaultValue={authorName} // Set default value
                            required
                        />
                    </div>
                </div>

                <div className="flex gap-8">
                    <div className="lg:w-1/2">
                        <div className="mb-2 block">
                            <Label htmlFor="imageurl" value="Book Image URL" />
                        </div>
                        <TextInput
                            id="imageurl"
                            type="text"
                            name="imageurl"
                            placeholder="Book Image URL"
                            defaultValue={imageurl} // Set default value
                            required
                        />
                    </div>
                    <div className="lg:w-1/2">
                        <div className="mb-2 block">
                            <Label htmlFor="inputState" value="Book Category" />
                        </div>
                        <select
                            id="inputState"
                            name="categoryName"
                            className="w-full rounded"
                            value={selectedBookCategory}
                            onChange={handleChangeSelectedValue}
                        >
                            {bookCategories.map((option) => (
                                <option key={option} value={option}>
                                    {option}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <div>
                    <div className="mb-2 block">
                        <Label htmlFor="bookDescription" value="Book Description" />
                    </div>
                    <Textarea
                        id="bookDescription"
                        name="bookDescription"
                        placeholder="Write your book description..."
                        defaultValue={bookDescription} // Set default value
                        required
                        rows={6}
                    />
                </div>

                <div>
                    <div className="mb-2 block">
                        <Label htmlFor="bookPdfUrl" value="Book PDF URL" />
                    </div>
                    <TextInput
                        id="bookPdfUrl"
                        type="text"
                        name="bookPdfUrl"
                        placeholder="Book PDF URL"
                        defaultValue={bookPdfUrl} // Set default value
                        required
                    />
                </div>

                <Button
                    type="submit"
                    className="mt-5 bg-black text-white mx-auto block"
                >
                    Update Book
                </Button>
            </form>
        </div>
    );
};

export default EditBook;
