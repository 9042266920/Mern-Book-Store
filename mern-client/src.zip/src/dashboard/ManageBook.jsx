import React, { useEffect, useState } from 'react';
import { Link } from "react-router-dom";

const ManageBook = () => {
    const [allBooks, setAllBooks] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5000/all-books") // Ensure the API is correct
            .then(res => {
                if (!res.ok) {
                    throw new Error("Network response was not ok");
                }
                return res.json();
            })
            .then(data => {
                setAllBooks(data);
            })
            .catch(error => console.error("Error fetching books:", error));
    }, []);

    const handleDelete = (id) => {
        // Use template literals correctly for the URL
        fetch(`http://localhost:5000/books/${id}`, {
            method: "DELETE",
        })
            .then(res => {
                if (!res.ok) {
                    throw new Error("Failed to delete the book");
                }
                return res.json();
            })
            .then(data => {
                alert("Book is deleted successfully!!!");
                // Filter out the deleted book from the state
                setAllBooks(allBooks.filter(book => book._id !== id));
            })
            .catch(error => console.error("Error deleting book:", error));
    };

    return (
        <div className="px-4 my-12">
            <h2 className="mb-8 text-3xl font-bold">Manage Your Books</h2>
            <div className="overflow-x-auto">
                <table className="min-w-full bg-gray-100 border border-gray-300">
                    <thead className="bg-gray-200">
                        <tr>
                            <th className="px-4 py-2 text-gray-900">Index</th>
                            <th className="px-4 py-2 text-gray-900">Book Name</th>
                            <th className="px-4 py-2 text-gray-900">Author Name</th>
                            <th className="px-4 py-2 text-gray-900">Category</th>
                            <th className="px-4 py-2 text-gray-900">Price</th>
                            <th className="px-4 py-2 text-gray-900">
                                <span className="sr-only">Edit or Manage</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-300">
                        {allBooks.map((book, index) => (
                            <tr key={book._id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-4 py-2 font-medium text-gray-900">{index + 1}</td>
                                <td className="px-4 py-2 font-medium text-gray-900">{book.bookTitle}</td>
                                <td className="px-4 py-2 text-gray-700">{book.authorName}</td>
                                <td className="px-4 py-2 text-gray-700">{book.category}</td>
                                <td className="px-4 py-2 text-gray-700">${book.price}</td>
                                <td className="px-4 py-2">
                                    <Link className="font-medium text-cyan-600 hover:underline mr-5" to={`/admin/dashboard/edit-book/${book._id}`}>
                                        Edit
                                    </Link>
                                    <button onClick={() => handleDelete(book._id)} className='bg-red-600 px-4 py-1 font-semibold text-white rounded-sm hover:bg-sky-600'>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ManageBook;
