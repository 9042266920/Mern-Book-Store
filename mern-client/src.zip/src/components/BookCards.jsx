import React from 'react';
import { Link } from 'react-router-dom';
import { FaCartShopping } from 'react-icons/fa6';  // Import FaCartShopping
import './BookCard.css';

const BookCards = ({ headline, books }) => {
    return (
        <div className='my-16 px-4 lg:px-24'>
            <h2 className='text-5xl text-center font-bold text-black my-5'>{headline}</h2>

            {/* cards */}
            <div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 mt-12'>
                {
                    books.map(book => (
                        <div key={book._id} className='relative'>
                            <Link to={`/book/${book._id}`}>
                                <div className='relative'>
                                    <img src={book.imageurl} alt="" />
                                    <div className='absolute top-3 right-3 bg-blue-600 hover:bg-black p-2 rounded'>
                                        <FaCartShopping className='w-4 h-4 text-white' />
                                    </div>
                                </div>
                                <div className='mt-4'>
                                    <h3>{book.bookTitle}</h3>
                                    <p>{book.authorName}</p>
                                    <p className='mt-2'>$10.00</p>
                                </div>
                            </Link>
                        </div>
                    ))
                }
            </div>
        </div>
    )
}

export default BookCards;
