import React from 'react'

const SingleBook = () => {
  return (
    <div>
      singlebook
    </div>
  )
}

export default SingleBook
