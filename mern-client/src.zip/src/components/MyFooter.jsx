import { Footer } from "flowbite-react";
import { BsDribbble, BsFacebook, BsGithub, BsInstagram, BsTwitter } from "react-icons/bs";

const MyFooter = () => {
    return (
        <Footer bgDark>
            <div className="w-full">
                <div className="grid w-full grid-cols-2 gap-8 px-6 py-8 md:grid-cols-4">
                    <div>
                        <Footer.Title title="Company" />
                        <Footer.LinkGroup col>
                            <Footer.Link href="#" className="hover:text-amber-500">About</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Careers</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Brand Center</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Blog</Footer.Link>
                        </Footer.LinkGroup>
                    </div>
                    <div>
                        <Footer.Title title="Help Center" />
                        <Footer.LinkGroup col>
                            <Footer.Link href="#" className="hover:text-amber-500">Discord Server</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Twitter</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Facebook</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Contact Us</Footer.Link>
                        </Footer.LinkGroup>
                    </div>
                    <div>
                        <Footer.Title title="Legal" />
                        <Footer.LinkGroup col>
                            <Footer.Link href="#" className="hover:text-amber-500">Privacy Policy</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Licensing</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Terms & Conditions</Footer.Link>
                        </Footer.LinkGroup>
                    </div>
                    <div>
                        <Footer.Title title="Download" />
                        <Footer.LinkGroup col>
                            <Footer.Link href="#" className="hover:text-amber-500">iOS</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Android</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">Windows</Footer.Link>
                            <Footer.Link href="#" className="hover:text-amber-500">MacOS</Footer.Link>
                        </Footer.LinkGroup>
                    </div>
                </div>
                <div className="w-full bg-gray-800 px-4 py-6 sm:flex sm:items-center sm:justify-between">
                    <Footer.Copyright href="#" by="Flowbite™" year={2022} className="text-gray-400" />
                    <div className="mt-4 flex space-x-6 sm:mt-0 sm:justify-center">
                        <Footer.Icon href="#" icon={BsFacebook} className="hover:text-amber-500 transition duration-300" />
                        <Footer.Icon href="#" icon={BsInstagram} className="hover:text-amber-500 transition duration-300" />
                        <Footer.Icon href="#" icon={BsTwitter} className="hover:text-amber-500 transition duration-300" />
                        <Footer.Icon href="#" icon={BsGithub} className="hover:text-amber-500 transition duration-300" />
                        <Footer.Icon href="#" icon={BsDribbble} className="hover:text-amber-500 transition duration-300" />
                    </div>
                </div>
            </div>
        </Footer>
    );
};

export default MyFooter;
