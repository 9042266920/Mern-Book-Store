import React from 'react';
import { FaStar } from "react-icons/fa6";
import sample from "../assets/sample.jpg";
import { Avatar } from "flowbite-react";

const reviews = [
    {
        stars: 4,
        review: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam a eum sed earum, optio iure libero autem quos in quis reiciendis.",
        name: "Mark Ping",
        designation: "CEO, ABC Company",
        img: sample
    },
    {
        stars: 5,
        review: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quaerat autem minus ratione facere!",
        name: "Jane Doe",
        designation: "CTO, XYZ Company",
        img: sample
    },
    {
        stars: 4,
        review: "Lorem ipsum dolor sit amet consectetur, minus ratione facere, quos in quis reiciendis optio iure libero autem.",
        name: "John Smith",
        designation: "Manager, DEF Corp",
        img: sample
    },
    {
        stars: 5,
        review: "Excellent service, couldn't ask for more! Veniam a eum sed earum, optio iure libero autem quos in quis reiciendis.",
        name: "Emily Rose",
        designation: "Head of Marketing, GHI Inc.",
        img: sample
    },
    {
        stars: 4,
        review: "Great experience, very helpful and supportive staff. Quaerat autem minus ratione facere! Highly recommended.",
        name: "Michael Lee",
        designation: "Software Engineer, JKL Ltd",
        img: sample
    }
];

const Review = () => {
    return (
        <div className='my-12 px-4 lg:px-24'>
            <h2 className='text-5xl font-bold text-center mb-10 leading-snug'>Our Customers</h2>
            <div className='overflow-x-auto'>
                <div className='flex space-x-6'>
                    {reviews.map((review, index) => (
                        <div 
                            key={index} 
                            className='min-w-[300px] max-w-[300px] bg-white shadow-xl rounded-lg p-6 flex-shrink-0'>
                            <div className='text-amber-500 flex gap-1 mb-4'>
                                {[...Array(review.stars)].map((_, i) => (
                                    <FaStar key={i} />
                                ))}
                            </div>
                            <p className='text-gray-700 mb-6'>{review.review}</p>
                            <div className='flex items-center'>
                                <Avatar img={review.img} alt={review.name} rounded className='w-10 h-10 mr-4' />
                                <div>
                                    <h5 className='text-lg font-medium'>{review.name}</h5>
                                    <p className='text-base'>{review.designation}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Review;
